export { crearDeck } from './crear-deck';
export { pedirCarta } from './pedir-carta';
export { turnoComputadora } from './turno-computador';
export { valorCarta } from './valor-carta';
export { crearCartaHTML } from './crear-carta-html';